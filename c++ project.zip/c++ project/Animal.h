#pragma once
#include <string>
class Animal
{
public:
	std::string Dialog() {
		return"";
	}
	std::string Name;
	int Age;

	Animal(std::string name,int age){
		Age = age;
		Name = name;
	}
};

