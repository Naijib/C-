#pragma once
#include "Animal.h"
class dog :
	public Animal
{
public:
	std::string Dialog() {
		return "woof";
	}
	std::string Race;
	dog(std::string race)
		: Animal(Name, Age) {
		Race = race;
	}
};

