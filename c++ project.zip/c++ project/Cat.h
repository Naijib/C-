#pragma once
#include "Animal.h"
#include <string>
class Cat :
	public Animal
{
	public:
	std::string Dialog(){
		 return "meow";
	}
	bool Hugger;
	Cat(bool hugger)
		: Animal(Name,Age){
		Hugger = hugger;
	}
};

